<?php
require_once('self/server/config.php');
require_once('self/server/functions.php');
$states = redef('q','select*from states where id = 31 or id = 39 order by id asc', $jr, 0);
$states2 = redef('q','select*from states order by id asc', $jr, 0);
$lgs = redef('q','select*from localgovernment where stateID =  31', $jr, 0);
$inst = redef('q','select*from institution order by id asc', $jr, 0);
if(isset($_POST['firstname']) and isset($_POST['lastname'])){
	$totalAmount = $_POST['amountDue'];
	$hostelName = $_POST['hostelName'];
	$roomName = $_POST['roomName'];
	$roomConfig = $_POST['config'];
	$xtraInfo = $_POST['comment'];
	$invitation = $_POST['invitationEmail'];
	$firstname = $_POST['firstname'];
	$lastname = $_POST['lastname'];
	$gender = $_POST['gender'];
	$birthday = $_POST['birthday'];
	$profilePic = $_FILES['profilePic']['name'];
	$phone = $_POST['phone'];
	$state = $_POST['state'];
	$LG = $_POST['LG'];
	$address = $_POST['address'];
	$institution = $_POST['institution'];
	$course = $_POST['course'];
	$courseDuration = $_POST['courseDuration'];
	$level = $_POST['level'];
	$program = $_POST['program'];
	$email = $_POST['email'];
	$username = $email;//$_POST['username'];
	$password = $phone;//$_POST['password'];
	$passwordAgain = $phone;
	$matric = $_POST['matric'];
	$invitations = explode(",",$invitation);
	if(!isset($totalAmount) or $totalAmount < 1){
		$message = eM('Sorry, Your hostel configuration is invalid!');
		return;
	}elseif($roomConfig == 2 and count($invitations) < 1){
		$message = eM('You have to Input at least an email to reserve bedspace for a proxy!');
		return;
	}
	if($roomConfig == 1 or $roomConfig == 3){
		$invitation = "";
	}
	if((strlen($firstname) >= 3 and validatestr($firstname,"str")) and strlen($lastname) >= 3){
		if(isset($birthday)){
			if(isset($phone) and strlen($phone) == 11 and validatestr($phone,"num")){
				if(isset($address)){
					if(isset($email) and validatestr($email, "mail")){
						if(strlen($username) >= 4){
							if(strlen($password) >= 6){
								if($password  == $passwordAgain){
									if(isset($_FILES['profilePic']['name'])){
										$fullname = $firstname." ".$lastname;
										$allowtype = array('jpg', 'jpeg','png');
										$form = strtolower($profilePic);
										$format = explode(".", $form);
										$type = end($format);
										if(in_array($type,$allowtype)){
											$s = getimagesize($_FILES['profilePic']['tmp_name']);
											if($s[0] >= 100 and $s[1] >= 100){
												if($_FILES['profilePic']['error'] == 0){
													if($s[0] < $s[1]){
														$maxsize = $s[1];
													}else{
														$maxsize = $s[0];
													}
													if($maxsize > 400){
														$redRat = 400/$maxsize;
													}else{
														$redRat = 1;
													}
													if(!file_exists("self/profileImages/".Mcrypt(time()))){
														mkdir("self/profileImages/".Mcrypt(time()));
													}else{
														//The username exists: unlikely though
													}
													$folder = "self/profileImages/".Mcrypt(time());
													$name = "S8_".time().".".$type;
													//$thumbname = "thumb_".$name;
													$tfile = $folder."/".$name;
													$thumbname = "thumb_".$name;
													$data = array("amountDue"=> $totalAmount,	"hostelName"=>$hostelName,	"roomName"=> $roomName,	"config"=>$roomConfig, "comment"=>$xtraInfo, "invitationEmail"=>$invitation, "username"=>$username, "email"=>$email, "password"=>$password, "fullname"=>$fullname, "gender"=>$gender, "birthday"=>$birthday, "profile"=>$tfile, "phone"=>$phone, "address"=>$address, "state"=>$state, "LG"=>$LG, "inst"=>$institution, "course"=>$course, "duration"=>$courseDuration, "matric"=>$matric, "level"=>$level, "pType"=>$program, "phone"=>$phone);
														$url = $base.'X/public/api/user/create/profile';
														$options = array(
																		 'http' => array(
																		 'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
																		 'method'  => 'POST',
																		 'content' => http_build_query($data)
																		  ));
														$context  = stream_context_create($options);
														$result = file_get_contents($url, true, $context);
														if ($result === FALSE) { /* Handle error */ }
														//var_dump($result);
														$data = json_decode($result);
														if($data->error->status > 0){
															$status = eM($data->error->message);
														}else{
															if(move_uploaded_file($_FILES["profilePic"]["tmp_name"], $tfile)){
															}
															resize_crop_image(round($s[0]*$redRat), round($s[1]*$redRat), $tfile, $tfile);
															thumbnail($thumbname,$name,$folder.'/',$folder.'/',50,50);
															$status = sM("Your Reservation has been succesful!");
															if($roomConfig == 2){
																$mess = "Thank You! <br/> Your hostel Reservation was succesfully booked. Please check your email for further instructions. Also encourage your friend to complete thier profile using the invite code sent to their email.";
															}else{
																$mess = "Thank You! <br/> Your hostel Reservation was succesfully booked. Please check your email for further instructions.";
															}
														}
													}else{
														$status = eM("The Image has errors! Use another image!");
														//image has errors
													}
												}else{
													$status = eM("The Image has size errors! Use image with bigger size!");
													//Image has size errors
												}
											}else{
												$status = eM("The Image format is unknown! Use another image!");
												//The Image is unknown type
											}
									}else{
										$status = eM("The Image field have not been set! Use another image!");
										//profile picture not set
									}
								}else{
									$status = eM("The Password fields do not match!");
									//password do not match
								}
							}else{
								$status = eM("The Password field expect at least 6 characters!");
								//password Length
							}
						}else{
							$status = eM("The username field expect at least 4 characters!");
							//username invalid
						}
					}else{
						$status = eM("The email is invalid. Use a valid email!");
						//email invalid
					}
				}else{
					$status = eM("The address field is invalid!");
					//address invalid
				}
			}else{
				$status = eM("The phone number field expect 11 characters Number only!");
				//Phone invalid
			}
		}else{
			$status = eM("The Bithday field is required!");
			//bithday incorrect
		}
	}else{
		$status = eM(" The Name fields are not properly filled out! ");
		///firstname Error
	}	
}
?>
<!doctype html>
<html class="no-js" lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1" />
        <!-- title -->
        <title>Accommodate | Registeration Form</title>
        <meta name="author" content="touchandpay">
        <!-- favicon -->
        <link rel="shortcut icon" href="images/icon/favicon.png">
        <!-- animation -->
        <link rel="stylesheet" href="css/bootstrap.min.css" />
        
        
        
        
        
        <!-- font-awesome icon -->
        <link rel="stylesheet" href="o/css/font-awesome.min.css" />
        <!-- themify-icons -->
        <link rel="stylesheet" href="o/css/themify-icons.css" />
        <!-- owl carousel -->
        <link rel="stylesheet" href="o/css/owl.transitions.css" />
        <link rel="stylesheet" href="o/css/owl.carousel.css" /> 
        <!-- magnific popup -->
        <link rel="stylesheet" href="o/css/magnific-popup.css" /> 
        <!-- base -->
        <link rel="stylesheet" href="o/css/base.css" /> 
        <!-- elements -->
        <link rel="stylesheet" href="o/css/elements.css" />
        <!-- responsive -->
        <link rel="stylesheet" href="o/css/responsive.css" />
        <link rel="stylesheet" href="self/style/governor.css" />
        
        
        
        <!--[if IE 9]>
        <link rel="stylesheet" type="text/css" href="o/css/ie.css" />
        <![endif]-->
        <!--[if IE]>
            <script src="o/js/html5shiv.min.js"></script>
        <![endif]-->
        
    </head>
    <body>
    <div id="stow" align="center"></div>
        
  
<header>
			
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo pull-left">
						<img src="images/logo.png" style="height: 55px; margin-top: 10px;" />
					</div><!-- //LOGO -->
					
					<!-- MENU -->
					<div class="pull-right">
						<nav class="navmenu center menu--iris">
							<ul>
								<li class="first active scroll_btn"><a href="index.html" >Home</a></li>
								<li class="sub-menu">
									<a href="our-location.html" >Our Location</a>
									<ul>
										<li><a href="location.html" >Yaba / Lagos</a></li>
										<li><a href="mapple.html" >L.A.S.U / Lagos</a></li>
										<li><a href="sycamore.html" >Ago-Iwoye / Ogun</a></li>
									</ul>
								</li>
								<li class="scroll_btn"><a href="our-story.html" >Our Story</a></li>
								<li class="sub-menu">
									<a href="our-location.html" >Living At SA8</a>
									<ul>
										<li><a href="blog.html" >Media</a></li>
										<li><a href="faq.html" >Faq</a></li>
										<li><a href="#" >Important Documents</a></li>
									</ul>
								</li>
								<li class="scroll_btn"><a href="contact.html" >Contact</a></li>
								<a href="#" data-toggle="modal" data-target="#connect-central" class="btn btn-medium propClone white text-white inner-link" style="border-color: #c02f26; background-color: #c02f26;">
									<span class="tz-text green" style="color: #ffffff;">CONNECT CENTRAL</span>
								</a>
								<div id="search-form" class="pull-right">
						<form method="get" action="#">
							<input type="text" name="Search" value="Search" onfocus="if (this.value == 'Search') this.value = '';" onblur="if (this.value == '') this.value = 'Search';">
						</form>
					</div>
							</ul>
						</nav>
					</div><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header>





<div class="container sm-no-padding" style="margin-bottom:10px;
    margin-top: 10px;
    padding-bottom: 50px;
    padding-right: 100px;
    padding-left: 100px; background:#FFF; border-bottom:#C3C3C3 thin solid; box-shadow: 0 5px 15px rgba(0,0,0,0.5); border-radius:5px;
">
<div class="modal-header">
					<div align="center"><h4>Book <span>Now</span></h4></div>
					<img src="images/book-now.jpg" alt=" " class="img-responsive">
					<h5 style="padding:10px 0px 10px 0px">Register to create account</h5>
				</div>
<form  action="register" method="post" enctype="multipart/form-data">
    <div class="row">
        <div class="board">
            <ul class="nav nav-tabs">
                <div class="liner"></div>
                <li rel-index="0" class="active">
                    <a href="#step-1" id="step1" class="btn" aria-controls="step-1" role="tab" data-toggle="tab">
                        <span><i class="fa fa-bed"></i></span>
                    </a>
                </li>
                <li rel-index="1" class="">
                    <a href="#step-2" id="step2" class="btn" aria-controls="step-2" role="tab" data-toggle="tab">
                        <span><i class="glyphicon glyphicon-user"></i></span>
                    </a>
                </li>
                <li rel-index="2" class="">
                    <a href="#step-3" id="step3" class="btn" aria-controls="step-3" role="tab" data-toggle="tab">
                        <span><i class="fa fa-graduation-cap"></i></span>
                    </a>
                </li>
                <!-- <li rel-index="2">
                    <a href="#step-3" class="btn disabled" aria-controls="step-3" role="tab" data-toggle="tab">
                        <span><i class="glyphicon glyphicon-edit"></i></span>
                    </a>
                </li> -->
                <li rel-index="3">
                    <a href="#step-4" id="step4" class="btn" aria-controls="step-4" role="tab" data-toggle="tab">
                        <span><i class="glyphicon glyphicon-file"></i></span>
                    </a>
                </li>
                 <?php
            if(isset($mess)){?>
                <li rel-index="4">
                    <a href="#step-5" id="step5" class="btn green" aria-controls="step-5" role="tab" data-toggle="tab">
                    <?php
			}else{?>
				<li rel-index="4">
                    <a href="#step-5" id="step5" class="btn disabled" aria-controls="step-5" role="tab" data-toggle="tab">
			<?php }
			?>
			
                        <span><i class="glyphicon glyphicon-ok"></i></span>
                    </a>
                </li>                
            </ul>
        </div>
        <div class="tab-content">
        
        
        
        <!--
        	This is the choose hostel tab
         -->
        
        <?php
            if(isset($mess)){?>
        <div role="tabpanel" class="tab-pane" id="step-1">
        <?php }else{ ?>
        <div role="tabpanel" class="tab-pane active" id="step-1">
        <?php
		}
		?>
                <div class="col-md-12">
                	<div class="row">
                    	<div class=""><h4 style="padding-bottom:10px">Hostel by location</h4></div>
                        <div class="col-sm-6" style="height:auto;">
                            <div class="form-group" style="height:70px; z-index:45000">
                                <label for="first-name">Select State</label><br>
                                <select class="form-control" style="z-index:4500000000" name="HostelState" id="hostelState" required onChange="matchList(this, 2)">
                                <?php
                                    while($ip = redef('f',$states,$jr,0)){ ?>
                                    <option value="<?php echo $ip['id']; ?>"><?php echo $ip['label']; ?></option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                          <div class="form-group" style="height:50px">
                              <label for="last-name" id="area">Choose Area</label><br>
                              <select class="form-control" name="schoolLG" id="schoolLGs" required onChange="listHostel(this)">
                                  <?php
                                  while($ip = redef('f',$lgs,$jr,0)){ ?>
                                  <option value="<?php echo $ip['id']; ?>"><?php echo $ip['label']; ?></option>
                                  <?php
                                  }
                                  ?>
                              </select>
                          </div>
                        </div>
                        <div class="" style="padding-bottom:10px; padding-top:90px; color:#304f82" align="center"><h4 style="color:#304f82">Select Hostel</h4></div>
                        <div class="col-sm-6">
                         <div class="form-group">
                                <label for="height" id="chooseHostel">Choose Hostel</label><br>
                                <select class="form-control" name="hostelName" id="hostelName" onChange="populateRooms(this.selectedIndex)"></select>
                            </div>
                         </div>
                        <div class="col-sm-6">
				             <div class="form-group">
				                    <label for="weight">Rooms Type</label><br>
				                    <select class="form-control" name="roomName" id="Rooms" onChange="findTotal()">
					                	
					                </select>
				            </div>
                        </div>
                        <div class="" style="padding-bottom:10px; padding-top:90px; color:#304f82" align="center"><h4 style="color:#304f82">Configure Room</h4></div>     
                        <div class="col-sm-6">
                          <div class="form-group">
                              <label for="birth-city">Choose Room-mate options</label><br>
                              <select class="form-control" name="config" id="config" onChange="findTotal()">
                                  <option value="1">I want the room to myself</option>
                                  <option value="2">I Will provide my room mate(s)</option>
                                  <option value="3">I only want a bedspace</option>
                              </select>
                          </div>
                        </div>
                        <div class="col-sm-6" id="optionalParam">
                          <div class="form-group">
                              <label for="birth-country">Send Room mate Invitation to </label><br>
                              <input type="text" name="invitationEmail" id="OptComment" class="form form-control" disabled placeholder="Separate multiple email with comma">
                          </div>
                        </div>
                        <p></p>
                        <div class="col-sm-11" id="optionalComment" style="padding-top:20px; max-height:100px">
                          <div class="form-group" align="center" style="max-height:80px">
                              <label for="birth-country">Optional Comment </label><br>
                              <textarea type="text" id="" name="comment" class="form form-control" style="max-width:70%; max-height:60" placeholder="Write optional comment on your booking"></textarea>
                          </div>
                        </div>
                       
                        <div class="col-sm-11" align="center" style="padding:20px">
                          <div class="form-group">
                           <input type="hidden" name="amountDue" id="amountDue" value="">
                            <hr/>
                              <h5>Total Amount Due: <span id="totalAmount"></span></h5>
                          </div>
                        </div>
                        
                	</div>  
                
                    <div class="col-md-12 text-center">
                        <button id="step-1-next"  class="btn btn-primary write nextBtn input-medium text-center" style="border-radius:0px; width: 100px; background-color: #304F82; border-color: #304F82; margin-top: 20px;">Next</button>
                    </div> 
              </div>
         </div>
        
        
        
        <!--
        	This the the personal Info tab
         -->
        
            <div role="tabpanel" class="tab-pane" id="step-2">
                <div class="col-md-12"> 
                <h4 style="padding-bottom:10px; padding-top:10px">Personal Information</h4>
                                <div class="col-md-6" style="height:auto">
	            				<div class="form-group" style="height:70px">
				                    <label for="first-name">First Name:</label><br>
				                    <input type="text" name="firstname" value="<?php echo isset($_POST['firstname'])? $_POST['firstname'] : '' ?>" class="form-control" id="firstname" required style="padding-bottom:8px;">
				                </div>
                                </div>
                                
                                <div class="col-md-6">
				                <div class="form-group" style="height:70px">
				                    <label for="last-name">Last Names:</label><br>
				                    <input type="text" name="lastname" value="<?php echo isset($_POST['lastname'])? $_POST['lastname'] : '' ?>" class="form-control" id="lastname" required style="padding-bottom:8px;">
				                </div>
                                </div>
                                
                                <div class="col-md-6">
				                <div class="form-group">
				                    <label for="height">Gender:</label><br>
				                    <select class="form-control" name="gender" id="gender">
					                	<option value="Male">Male</option>
					                	<option value="Female" <?php echo isset($_POST['gender']) and ($_POST['gender']== "Female")? "selected='selected'" : "" ?>>Female</option>
					                </select>
				                </div>
                                </div>
                                
                                <div class="col-md-6">
				                <div class="form-group">
				                    <label for="weight">Birthday (DD/MM/YYYY):</label><br>
				                    <input type="date" name="birthday" value="<?php echo isset($_POST['birthday'])? $_POST['birthday'] : '' ?>" class="weight form-control" id="birthday" placeholder="dd/mm/yy">
				                </div>
                                </div>
                                
                                <div class="col-md-11" style="padding-bottom:8px; padding-top:8px; height:70px">
                                <input type="file" name="profilePic" id="profilePic" style="display:none">
	            				<button type="file" class="btn btn-info" style="background:#304f82; border-radius:0px; border:none;" onClick="document.getElementById('profilePic').click()"><i class="fa fa-image"></i> Upload Passport Picture</button>
	            			</div>
                            
                          <hr style="padding:12px" />
	            				<div class="col-sm-11" align="center"><h4 style="padding-top:20px; padding-bottom:10px; color:#304f82">Other Information</h4></div>                                
                                <div class="col-md-6">
	            				<div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="birth-city">Phone No:</label><br>
				                    <input type="number" value="<?php echo isset($_POST['phone'])? $_POST['phone'] : '' ?>" min="1" name="phone" maxlength="11" class="telephone form-control" id="phone-no" required>
				                </div>
                                </div>
                                
                                <div class="col-md-6">
				                <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="birth-country">State / Province of Origin:</label><br>
				                    <select class="form-control" name="state" id="state" required onChange="matchList(this)">
                                    <?php
										while($ip2 = redef('f',$states2,$jr,0)){ ?>
					                	<option value="<?php echo $ip2['id']; ?>"><?php echo $ip2['label']; ?></option>
                                        <?php
										}
										?>
					                </select>
				                </div>
                                </div>
                                
                                <div class="col-md-6">
				                <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="birth-date" id="lg">Local Government of Origin:</label><br>
				                    <select class="form-control" name="LG" id="LGs" required>
					                	<?php
										while($ip = redef('f',$lgs,$jr,0)){ ?>
					                	<option value="<?php echo $ip['id']; ?>"><?php echo $ip['label']; ?></option>
                                        <?php
										}
										?>
					                </select>
				                </div>
                                </div>
                                <div class="col-md-6">
                                 <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="birth-state">Address:</label><br>
				                    <input type="text" value="<?php echo isset($_POST['address'])? $_POST['address'] : '' ?>" name="address"  class="address form-control" id="address" style=""  required>
				                </div>
                                </div>
                                <div class="col-sm-6">
           						 <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="address-city">Email:</label><br>
				                    <input type="email" name="email" value="<?php echo isset($_POST['email'])? $_POST['email'] : '' ?>" class="address-city form-control" required>
				                </div>
                                </div>
                
                    <div class="col-md-11 text-center">
                        <button id="step-2-next" class="btn btn-primary write input-medium text-center pull-right" style="border-radius:0px; width: 100px; background-color: #304F82; border-color: #304F82; margin-top: 20px; margin-bottom: 30px;">Next</button>
                    <button id="step-1-next" onClick="validate(1)" class="btn btn-primary bluenew input-medium text-center pull-left" style="border-radius:0px; width: 100px; background-color: transparent; border-color: #304F82; margin-top: 20px;">Back</button>
                    </div>
               </div>
          </div>
            
            
            
            
            
            <!-- 
           		Institution tab
            -->
            
            <div role="tabpanel" class="tab-pane" id="step-3">
            <div class="col-sm-12"><h4>Instituition Information</h4></div>
            <div class="col-sm-6">
            <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
                                  <label for="institution">Instituition:</label><br>
                                  <select class="form-control" name="institution" required id="institution">
                                  <?php
                                      while($ip = redef('f',$inst,$jr,0)){ ?>
                                      <option value="<?php echo $ip['id']; ?>"><?php echo $ip['schoolName']; ?></option>
                                      <?php
                                      }
                                      ?>
                                  </select>
                              </div>
                              </div>
                                
                                <div class="col-sm-6">
				                <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="address-city">Course:</label><br>
				                    <input type="text" name="course" value="<?php echo isset($_POST['course'])? $_POST['course'] : '' ?>" class="address-city form-control" id="course" required>
				                </div>
                                </div>
                                <div class="col-sm-6">
				                <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="address-state">Course Duration:</label><br>
				                    <input type="number" name="courseDuration" min="1" value="<?php echo isset($_POST['courseDuration'])? $_POST['courseDuration'] : '' ?>" class="address-state form-control" id="course-duration" required>
				                </div>
                                </div>
                                <div class="col-sm-6">
				                <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="address-country">Matric Number:</label><br>
				                    <input type="text" name="matric" value="<?php echo isset($_POST['matric'])? $_POST['matric'] : '' ?>" class="address-country form-control" id="matric-number" required>
				                </div>
                                </div>
                                <div class="col-sm-6">
				                <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="address-postal-code">Level / Current year:</label><br>
				                    <input type="number" min="1" name="level" value="<?php echo isset($_POST['level'])? $_POST['level'] : '' ?>" class="address-postal-code form-control" id="level" required>
				                </div>
                                </div>
                                <div class="col-sm-6">
				                <div class="form-group" style="padding-bottom:8px; padding-top:8px; height:70px">
				                    <label for="telephone">Programme:</label><br>
				                    <select class="form-control" name="program" required id="progType">
					                	<option value="Post Graduate">Post Graduate</option>
					                	<option value="Under Graduate" <?php echo isset($_POST['program']) and $_POST['program']== "Under Graduate"? "selected='selected'" : "" ?>>Under Graduate</option>
					                </select>
				                </div>
                                </div>
                    
                    
                    <button id="step-3-next" class="btn btn-primary write input-medium text-center pull-right" style="border-radius:0px; width: 100px; background-color: #304F82; border-color: #304F82; margin-top: 20px; margin-bottom: 30px;">Next</button>
                    <button id="step-2-next" class="btn btn-primary bluenew input-medium text-center pull-left" style="border-radius:0px; width: 100px; background-color: transparent; border-color: #304F82; margin-top: 20px;">Back</button>
               
            </div>
            
              
            
            <!--
            	Preview page
             -->           
            
            <div role="tabpanel" class="tab-pane" id="step-4">
            <div class="col-sm-12">
            <h4>Preview your application </h4>
            </div>
            	<div class="col-sm-12" style="padding-left:30px; padding-top:20px; padding-bottom:15px; font-family:'Palatino Linotype', 'Book Antiqua', Palatino, serif"><h6>Hostel Booking Details</h6>
                	<div class="row">
                        <div class="col-lg-6" style="font-size:16px; padding-top:10px; word-break:break-word">
                            <span style="font-weight:bold" id="hosteln">Hostel Name: </span><br/>
                            <span id="hostela"></span>
                        </div>
                        <div class="col-lg-6" style="font-size:16px; padding-top:10px">
                            <span style="font-weight:bold">Room Name: <span id="roomn"> </span></span>
                            <br/>
                            <span style="font-weight:bold">Room Type: <span id="roomt"></span></span>
                        </div>
                        <div class="col-lg-6" style="font-size:16px; padding-top:10px">
                            <span style="font-weight:bold">Configuration: <span id="conf"></span></span>                            
                        </div>
                        <div class="col-lg-6" style="font-size:16px; padding-top:10px">
                            <h6 style="font-weight:bold">Total Price: <span id="pr"></span></h6>                            
                        </div>
                    </div>
                </div>
                
                <div class="col-sm-12" style="padding-left:30px; padding-top:20px; font-family:'Palatino Linotype', 'Book Antiqua', Palatino, serif"><h6>Personal Information Details</h6>
                	<div class="row" style="font-size:16px; padding-top:10px">
                    	<div class="col-md-6">Fullname: <span id="fns"></span></div>
                        <div class="col-md-6">Gender: <span id="sOg"></span></div>
                        <div class="col-md-6">Birthday: <span id="bd"></span></div>
                        <div class="col-md-6">Phone Number: <span id="pn"></span></div>
                        <div class="col-md-6">Location: <span id="loc"></span></div>
                    </div>
                </div>
                <div class="col-sm-12" style="padding-left:30px; padding-top:20px; font-family:'Palatino Linotype', 'Book Antiqua', Palatino, serif"><h6>Institution Information Details</h6>
                	<div class="row" style="font-size:16px; padding-top:10px">
                    	<div class="col-md-6">Institution: <span id="inst"></span></div>
                        <div class="col-md-6">Course: <span id="cus"></span></div>
                        <div class="col-md-6">Course-Duration: <span id="cdur"></span></div>
                        <div class="col-md-6">Matric: <span id="mtr"></span></div>
                        <div class="col-md-6">Current Year: <span id="cy"></span></div>
                        <div class="col-md-6">Programme: <span id="pgT"></span></div>
                    </div>
                </div>
  
            
            
            <hr style="padding:10px" />
            
                <div class="col-md-2" align="right" style="padding-top:7px; margin-right:-77px">
                <div align="right"><input type="checkbox" name="" required id="termsCheck"></div>
                </div>
                <div class="col-md-4" align="left" style="padding:0px">
                <div align="left"><div class="btn btn-link" data-toggle="modal" data-target="#form-wizard" style="border-radius:0px;">I Accept Terms and Condition</div></div>
                </div>
                
                  <div class="col-md-6">                                       
                    <button type="submit" class="btn btn-primary write input-medium text-center pull-right" style="border-radius:0px; width: 100px; background-color:#304F82; border-color: #304F82; margin-top: 20px; margin-bottom: 30px; margin-right: 10px;">Submit</button>
                </div>
            </div>
            
            
            
            
            
            
            <!--
            	The Consent 
             -->
             <?php
            if(isset($mess)){
				echo '<div role="tabpanel" class="tab-pane active" id="step-5">';
			}else{
				echo '<div role="tabpanel" class="tab-pane" id="step-5">';
			}
			?>
            <div class="col-sm-12">
            <div align="center" style="padding:17px"><i class="fa fa-check-circle fa-2x"></i><h5 style="color:#3D8D16">
            
			<?php
            if(isset($mess)){
				echo $mess;
			}
			?>
			</h5></div>
                </div>
            </div>
            <!--
            	The end of content
            -->          
            
            
            
            
        </div>
        
        
    </div></form>
</div>
        
        
        
        <div class="row" style="background:#1c1c1c; padding-top:20px; max-width:101%;">
		<div class="container" style="background:#1c1c1c; padding-left:0px; padding-right:0px;">
			
			<!-- ROW -->
            <style>
			h4{margin:0,0,0,34px;}
			</style>
			<div class="row">				
				<div class="col-lg-4 col-md-4 col-sm-6 padbot30" style="padding: 5% 5% 5% 0;">
					<img src="images/logo.png" style="width: 250px; height: 80px;">
				</div>				
				<div class="col-lg-4 col-md-4 col-sm-6 padbot30 foot_about_block">
					<h4 style="margin-bottom:34px; color:#FFF"><b>Footer</b> Links</h4>
					<div class="row">
						<div class="col-md-6 col-sm-6 col-xs-12 xs-margin-nine-bottom xs-text-center">
	                        <ul class="links">
	                            <li class="text-medium margin-seven-bottom font-weight-600  tz-text xs-margin-one-half-bottom">QUICK LINKS</li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="our-story.html">Our Story</a></li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="our-location.html">Our Location</a></li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="#" data-toggle="modal" data-target="#connect-central">Connect Central</a></li>
	                        </ul>
	                    </div>
	                    <div class="col-md-6 col-sm-6 col-xs-12 xs-margin-nine-bottom xs-text-center">
	                        <ul class="links">
	                            <li class="text-medium margin-seven-bottom font-weight-600 tz-text xs-margin-one-half-bottom">INFORMATION</li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="faq.html">FAQ's</a></li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="#">Term's &amp; Condition</a></li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="#">Privacy Policy</a></li>
	                        </ul>
	                    </div>
					</div>
				</div>
				
				<div class="respond_clear"></div>
				<div class="col-lg-4 col-md-4 padbot30">
					<h4 style="margin-bottom:34px; color:#FFF"><b>Find</b> Us</h4>	
					<ul class="social">
						<li><a href="http://twitter.com/SAccommod8" target="_blank"><i class="fa fa-twitter"></i></a></li>
						<li><a href="http://facebook.com/studentaccommod8" target="_blank"><i class="fa fa-facebook"></i></a></li>
						<li><a href="http://instagram.com/SAccommod8" target="_blank"><i class="fa fa-instagram"></i></a></li>
						<li><a href="http://linkedin.com/SAccommod8" target="_blank"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="javascript:void(0);" ><i class="map_show fa fa-map-marker"></i></a></li>
					</ul>
					<ul class="links">
                        <li>
                        	<span class="text-medium margin-seven-bottom font-weight-600 tz-text xs-margin-one-half-bottom">OFFICE:</span>
                        	<span style="margin-left: 50px;">13 Akin Leigh Cres, Lekki Phase I, Lagos.</span>
                        </li>
                        <li>
                        	<span class="text-medium margin-seven-bottom font-weight-600 tz-text xs-margin-one-half-bottom">TELEPHONE:</span>
                        	<span style="margin-left: 20px;">+234 812 345 6789</span>
                        </li>
                    </ul>
				</div>
			</div><!-- //ROW -->
			<div class="row copyright">
				<div class="col-lg-12 text-center">
					<p>© 2017 Accommodate is Proudly Powered By <a href="http://sanwo.me/" target="_blank">Sanwo touch2pay</a>.</p>
				</div>
			
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
        </div>
        <style>
		.terms ol li{
			list-style:decimal !important;
		}
		.terms h6{
			color:#c02f26;
			padding:10px 4px 10px 4px
		}
		.term{
			font-family:'Roboto', sans-serif !important;
		}
		</style>
        <div class="modal fade" id="form-wizard" tabindex="-1" role="dialog" style="z-index:10000;">
		<div class="modal-dialog" style="width:80%">
		<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header" style="padding:20px">
					<button type="button" class="close" data-dismiss="modal">&times;</button>					
				</div>
				<div class="terms" style="padding:10px 40px 10px 115px">
                <h3 style="color:#3e5e9a">Terms and Condition/Tenancy Agreement</h3>
                  <h6>Part I. General Provisions</h6>
                  <ol>
                    <li><span dir="LTR"> </span>All rent, service charge and diesel deposit  paid are in advance. </li>
                    <li><span dir="LTR"> </span>These regulations are  designed to ensure that student’s accommodation and surrounding areas is a safe  and comfortable environment for living and learning and have been formulated in  relation to the Student Accommod8 Terms and Conditions. </li>
                    <li><span dir="LTR"> </span>These regulations apply to  all students and visitors in the residence buildings and surrounding areas at  all times. </li>
                     <li><span dir="LTR"> </span>The Security and Student  Accommodation Management Office is responsible for the day-to-day management of  the student residences. Hall Wardens, Student Affairs Assistants in the  residence and the Security Department jointly take responsibility for the  implementation of these regulations. </li>
                     <li><span dir="LTR"> </span>Student Accommod8 will work  closely with the Student Community Residents Group to facilitate the  implementation of these regulations. </li>
                     <li><span dir="LTR"> </span>Rent period is 11 months and  2 weeks. SA8 would evacuate the hotel for a 2 week period anytime in the year  for renovation purspose. </li>
                  </ol>
                  <h6>Part II. Safety and Security</h6>
                  <ol>
                    <li><span dir="LTR"> </span>Any sort of combustible,  explosive, corrosive or poisonous materials that may cause damage or constitute  a treat to health and safety are strictly forbidden anywhere in or near the  residence areas. </li>
                  
                    <li><span dir="LTR"> </span>Students must not bring or  store knives or guns (including replicas) or any other items that may threaten  personal safety. </li>
                  
                    <li><span dir="LTR"> </span>Lighting of fires and setting  off fireworks anywhere in or near the residence areas is strictly forbidden. </li>
                  
                    <li><span dir="LTR"> </span>Tampering with or inappropriate  use of fire safety equipment or misuse of emergency phone numbers is strictly  forbidden. Any suspected damage to fire safety equipment should be reported to  the relevant Student Accommodation Manager in Student Accommodation Management  Office immediately. </li>
                 
                    <li><span dir="LTR"> </span>Students are not allowed to  bring the following items into their rooms or the residence buildings:  briquette stoves, kerosene stoves, spirit stoves, electrical stoves, electric  cookers, solid fuels, clothes washing or drying machines, any form of heating  appliance, or any other unauthorized electrical device. All such items will be  confiscated. </li>
                  
                    <li><span dir="LTR"> </span>Students must not light candles or install  electrical wiring in their rooms or public areas. </li>
                  
                    <li><span dir="LTR"> </span>Students are not permitted to  keep any pets, such as cats, dogs, birds, or similar inside their rooms or  elsewhere in residence. </li>
                 
                    <li><span dir="LTR"> </span>Students are responsible for  their own valuables. Extra cash should be stored in the bank and chequebooks  and ATM cards should be kept appropriately. </li>
                 
                    <li><span dir="LTR"> </span>Students are required to lock  all drawers, cabinets and doors when they are away from their room. </li>
                  
                    <li><span dir="LTR"> </span>Students are not permitted to add, change or  tamper with door locks. </li>
                  
                    <li><span dir="LTR"> </span>Students are responsible for  the safe keeping of their keys. Lost or stolen keys must be reported  immediately to the Student Accommodation Management Office. </li>
                  
                    <li><span dir="LTR"> </span>Students are not permitted to duplicate keys  and must not lend their keys to anyone. </li>
                  
                    <li><span dir="LTR"> </span>Students can borrow a key to their room with  proof of identity. </li>
                  
                    <li><span dir="LTR"> </span>Unauthorized selling of good or  services within residences is forbidden. Students should report any strangers  or suspicious individuals engaging in such activity immediately to the Student  Accommodation Management Office. </li>
                    <li><span dir="LTR"> </span>Smoking is not allowed in the residence  buildings. </li>                  
                    <li><span dir="LTR"> </span>Involvement in the use and or  distribution of illegal drugs in residence is very strictly forbidden and will  be treated as extremely serious by Student Accommod8. </li>                 
                    <li><span dir="LTR"> </span>Students are required to  follow the established rules and procedures for receiving guests or visiting students  in dormitories other than their own. </li>
                   <li><span dir="LTR"> </span>Students who wish to change  room or move out of the dormitory must follow the established rules and  procedures. </li>
                  </ol>
                  <h6>Part III. Standards of Behaviour</h6>
                  <ol>
                    <li><span dir="LTR"> </span>Loud and disruptive behaviour, which disturbs  the rest and study of other residents, is forbidden. </li>
                    <li><a name="page13"></a><span dir="LTR"> </span>Throwing any items whatsoever out of windows  and doors is strictly forbidden. </li>
                  
                    <li><span dir="LTR"> </span>Any form of gambling is strictly forbidden. </li>
                  
                    <li><span dir="LTR"> </span>Students are mandated to  respect the property managers and abide by the rules ad regulations of Student  Accommod8 at all times. Any form of harassment of any the property managers  will not be tolerated. </li>                  
                    <li><span dir="LTR"> </span>Cooking in the Rooms is <strong>Strictly Prohibited.</strong> All Culinary activities  must take place in the Kitchen provided in the dormitory. </li>
                  </ol>
                  <h6>Part IV. Quiet Hours and Access</h6>
                  <ol>
                    <li><span dir="LTR"> </span>Quiet hours in and around the dormitories are  from 10:00pm to 07:00 am every day. </li>
                    <li><span dir="LTR"> </span>Visiting hours in the dormitories are from  9am to 9pm daily. </li>                 
                    <li><span dir="LTR"> </span>Visitors are <strong>STRICTLY PROHIBTED</strong> from Sleep Overs in the dormitories. </li>
                    <li><span dir="LTR"> </span><strong>Squatters are  STRICTLY PROHIBTED </strong>from the dormitories. </li>                  
                    <li><span dir="LTR"> </span>During exam periods quiet hours are extended  to 24 hours. </li>                  
                    <li><span dir="LTR"> </span>Students are prohibited from making excessive  noise. </li>                  
                    <li><span dir="LTR"> </span>Doors are normally opened at  06:00 am and closed at 23:00 pm. During weekends and holidays, or during exam  periods, the doors will be closed at 23:30 pm. </li>
                    <li><span dir="LTR"> </span>Entry into the Students Accommodation is by  showing security access card. </li>
                  </ol>
                 <h6>Part V. Miscellaneous Provisions</h6>
                  <ol>
                    <li><span dir="LTR"> </span>Students are expected to keep their rooms and  residence areas clean and tidy. </li>
                    <li><span dir="LTR"> </span>Students should use water and  electricity sparingly and must ensure that all lights and water are switched  off when not needed. </li>
                    <li><span dir="LTR"> </span>Students should make use of recycling when  disposing of waste. </li>
                    <li><span dir="LTR"> </span>Any sort of unauthorized  redecorating is not permitted. This includes setting cords for drying clothes  in rooms or along corridors. </li>
                   <li><span dir="LTR"> </span>Students must not remove or relocate items of  furniture. </li>
                    <li><span dir="LTR"> </span>Students must exercise due  care and attention when using any public facilities to avoid damage and should  report any faults or damage. </li>
                    <li><span dir="LTR"> </span>Students and visitors in the  residence are subject to Student Accommod8’s regulations governing the use of  information services, including the Internet and DSTV. </li>
                  </ol>
                  <h6>Part VI. Supplementary Provisions</h6>
                  <ol>
                    <li><span dir="LTR"> </span>Students suspected of breaking one or more of  these regulations will be subject to the Student Accommod8’s eviction  policy</li>                         
                    <li><span dir="LTR"> </span>The right of interpretation of these  regulations rests with Student Accommod8. </li>
                     <p>I, <span id="anFullname"></span> have read the above “Student Accommod8  Regulations for Students Residence” and agree to abide by all the stipulated  terms and conditions.</p>
                     </ol>
                     
                     <div align="center" style="padding:20px 0px"><div class="btn btn-primary" class="close" data-dismiss="modal">Accept and Proceed</div></div>
				</div>
			</div>
		</div>
	</div>
        
        
        

        <!-- javascript libraries -->
        <script type="text/javascript" src="o/js/jquery.min.js"></script>
        <script type="text/javascript" src="o/js/jquery.appear.js"></script>
        <script type="text/javascript" src="o/js/smooth-scroll.js"></script>
        <script type="text/javascript" src="o/js/bootstrap.min.js"></script>
        <!-- wow animation -->
        <script type="text/javascript" src="o/js/wow.min.js"></script>
        <!-- owl carousel -->
        <script type="text/javascript" src="o/js/owl.carousel.min.js"></script>        
        <!-- images loaded -->
        <script type="text/javascript" src="o/js/imagesloaded.pkgd.min.js"></script>
        <!-- isotope -->
        <script type="text/javascript" src="o/js/jquery.isotope.min.js"></script> 
        <!-- magnific popup -->
        <script type="text/javascript" src="o/js/jquery.magnific-popup.min.js"></script>
        <!-- navigation -->
        <script type="text/javascript" src="o/js/jquery.nav.js"></script>
        <!-- equalize -->
        <script type="text/javascript" src="o/js/equalize.min.js"></script>
        <!-- fit videos -->
        <script type="text/javascript" src="o/js/jquery.fitvids.js"></script>
        <!-- number counter -->
        <script type="text/javascript" src="o/js/jquery.countTo.js"></script>
        <!-- time counter  -->
        <script type="text/javascript" src="o/js/counter.js"></script>
        <!-- twitter Fetcher  -->
        <script type="text/javascript" src="o/js/twitterFetcher_min.js"></script>
        <!-- main -->
        <script type="text/javascript" src="o/js/main.js"></script>
        <script>
            $(function() {
    // Nav Tab stuff
    $('.nav-tabs > li > a').click(function() {
        if($(this).hasClass('disabled')) {
            return false;
        } else {
            var linkIndex = $(this).parent().index() - 1;
            $('.nav-tabs > li').each(function(index, item) {
                $(item).attr('rel-index', index - linkIndex);
            });
        }
    });
    $('#step-1-next').click(function() {
        // Check values here
        var isValid = true;
        
        if(isValid) {
            $('.nav-tabs > li:nth-of-type(2) > a').removeClass('disabled').click();
        }
    });
    $('#step-2-next').click(function() {
        // Check values here
        var isValid = true;
        
        if(isValid) {
            $('.nav-tabs > li:nth-of-type(3) > a').removeClass('disabled').click();
        }
    });
    $('#step-3-next').click(function() {
        // Check values here
        var isValid = true;
        
        if(isValid) {
            $('.nav-tabs > li:nth-of-type(4) > a').removeClass('disabled').click();
        }
    });
	$('#step-4-next').click(function() {
        // Check values here
        var isValid = true;
        
        if(isValid) {
            $('.nav-tabs > li:nth-of-type(4) > a').removeClass('disabled').click();
        }
    });
	$('#step-5-next').click(function() {
        // Check values here
        var isValid = true;
        
        if(isValid) {
            $('.nav-tabs > li:nth-of-type(4) > a').removeClass('disabled').click();
        }
    });
});
        </script>        
        <script type="text/javascript" src="self/script/s.js"></script>
        <script type="text/javascript">
        <?php
		if(isset($status)){
			echo "mCra('".str_replace("'","",$status)."')";
		}?>
    </script>
    </body>
</html>
