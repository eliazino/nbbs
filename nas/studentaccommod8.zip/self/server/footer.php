<style>
body a {
    text-decoration: none !important;
    transition: 0.5s all;
    -webkit-transition: 0.5s all;
    -moz-transition: 0.5s all;
    -o-transition: 0.5s all;
    -ms-transition: 0.5s all;
}



a{
    vertical-align: top;
    outline: none !important;
    -webkit-appearance: none;
    -webkit-border-radius: 0;
}
footer .links{
color: #999 !important;
}
footer h4 {
    color: #fff;
}
</style>
<footer>
			
		<!-- CONTAINER -->
		<div class="container">
			
			<!-- ROW -->
			<div class="row" data-appear-top-offset="-200" data-animated="fadeInUp">
				
				<div class="col-lg-4 col-md-4 col-sm-6 padbot30" style="padding: 5% 5% 5% 0;">
					<img src="images/logo.png" style="width: 250px; height: 80px;">
				</div>
				
				<div class="col-lg-4 col-md-4 col-sm-6 padbot30 foot_about_block" style="padding-top: 72px;">
				
					<div class="row">
						<div class="col-md-6 col-sm-6 col-xs-12 xs-margin-nine-bottom xs-text-center">
	                        <ul class="links">
	                            
	                            <li><a class="tz-text text-medium-gray inner-link" href="our-story.html">Our Story</a></li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="our-location.html">Our Location</a></li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="#" data-toggle="modal" data-target="#connect-central">Connect Central</a></li>
	                        </ul>
	                    </div>
	                    <div class="col-md-6 col-sm-6 col-xs-12 xs-margin-nine-bottom xs-text-center">
	                        <ul class="links">
	                            
	                            <li><a class="tz-text text-medium-gray inner-link" href="faq.html">FAQ's</a></li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="#" data-toggle="modal" data-target="#terms">Terms &amp; Condition</a></li>
	                            <li><a class="tz-text text-medium-gray inner-link" href="#" data-toggle="modal" data-target="#privacy-modal">Privacy Policy</a></li>
	                        </ul>
	                    </div>
					</div>
				</div>
				
				<div class="respond_clear"></div>
				<div class="col-lg-4 col-md-4 padbot30">
					<h4><b>Find</b> Us</h4>	
					<ul class="social">
						<li><a href="http://twitter.com/SAccommod8" target="_blank"><i class="fa fa-twitter"></i></a></li>
						<li><a href="http://facebook.com/studentaccommod8" target="_blank"><i class="fa fa-facebook"></i></a></li>
						<li><a href="https://www.instagram.com/studentaccommod8/" target="_blank"><i class="fa fa-instagram"></i></a></li>
						<li><a href="https://www.linkedin.com/company-beta/10306562/" target="_blank"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="https://www.google.com/maps/place/13+Akin+Leigh+Cres,+Lekki+Phase+I,+Lagos,+Nigeria/@6.4458579,3.4535004,17z/data=!3m1!4b1!4m5!3m4!1s0x103bf4f968dc17ed:0x1f58f5f7b48c2eea!8m2!3d6.4458579!4d3.4556891" ><i class="map_show fa fa-map-marker"></i></a></li>
					</ul>
					<ul class="links">
                        <li>
                        	
                        	<span >13 Akin Leigh Crescent, Lekki Phase I, Lagos.</span>
                        </li>
                        <li>
                        	
                        	<span >0806 067 1077, 01-454 5951</span>
                        </li>
                        <li>
                        	
                        	<span class="fa fa-whatsapp" aria-hidden="true">  0701 400 1692</span>
                        </li>
                        <li>
                        	
                        	<span>hello@studentaccommod8.com</span>
                        </li>
                    </ul>
				</div>
			</div><!-- //ROW -->
			<div class="row copyright">
				<div class="col-lg-12 text-center">
					<p>© 2017 Student Accommod8<!--<a href="http://sanwo.me/" target="_blank">Sanwo touch2pay</a>-->.</p>
				</div>
			
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer>