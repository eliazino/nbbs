		<header>
			<meta name="keywords" content="student accommodation, student accommod8, accommodation for students, student housing, University Accommodation, student hostels, hostel Nigeria, accommodation Nigeria, university housing, university
 hostels, university accommodation, student living, hostels, university lifestyle" />
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo pull-left">
						<img src="images/logo.png" style="height: 55px; margin-top: 10px;" />
					</div><!-- //LOGO -->
					
					<!-- MENU -->
					<div class="pull-right menu-width">
						<nav class="navmenu center menu--iris">
							<ul>
								<li class="first active scroll_btn"><a href="index.html" >Home</a></li>
								<li class="sub-menu">
									<a href="our-location.html" >Our Locations</a>
									<ul>
										<li><a href="location.html" >Yaba / Lagos state</a></li>
										<li><a href="maple.html" >LASU / Lagos state</a></li>
										<li><a href="sycamore.html" >Ago-Iwoye / Ogun State</a></li>
									</ul>
								</li>
								<li class="scroll_btn"><a href="our-story.html" >Our Story</a></li>
								<li class="sub-menu">
									<a>Living At SA8</a>
									<ul>
										
										<li><a href="faq.html" >Faq</a></li>
										<li><a href="#" >Important Documents</a></li>
									</ul>
								</li>
								
								<li class="sub-menu">
									<a>More</a>
									<ul>
										<li><a href="blog.html" >Media</a></li>
										<li><a href="contact.html" >Contact Us</a></li>
										
									</ul>
								</li>
								<a href="#" data-toggle="modal" data-target="#connect-central" class="btn btn-medium propClone white text-white inner-link" style="border-color: #c02f26; background-color: #c02f26;">
									<img src="images/l1.png"><span class="tz-text green" style="color: #ffffff; margin-left: 5px; letter-spacing: 3px;"><strong>CONNECT</strong>CENTRAL</span>
								</a>
								<div id="search-form" class="pull-right">
						<form method="get" action="#">
							<input type="text" name="Search" value="Search" onfocus="if (this.value == 'Search') this.value = '';" onblur="if (this.value == '') this.value = 'Search';">
						</form>
					</div>
							</ul>
						</nav>
					</div><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
    <div id="stow" align="center"></div>