<?php
$base = "http://localhost/bitx/";
?>